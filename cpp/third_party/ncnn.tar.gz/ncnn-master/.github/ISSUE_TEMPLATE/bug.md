---
name: "\U0001F41B bug issue"
about: submit a bug report +_+
---

## error log | 日志或报错信息 | ログ

## context | 编译/运行环境 | バックグラウンド

## how to reproduce | 复现步骤 | 再現方法
1.
2.
3.

## more | 其他 | その他
