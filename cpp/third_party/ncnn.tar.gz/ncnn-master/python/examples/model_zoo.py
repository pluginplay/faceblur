# Copyright 2020 Tencent
# SPDX-License-Identifier: BSD-3-Clause

from ncnn.model_zoo import get_model_list

if __name__ == "__main__":
    print(get_model_list())
